﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandwichShop
{
    public partial class frmStart : Form
    {
        int numOfSandwich = 1;
        double subTotal = 0;
        double tax = 0;
        double total = 0;
        int invalidCounter = 0;
        int subCounter = 0;
        List<Sandwich> allSandwiches = new List<Sandwich>();
        Sandwich sm = new Sandwich();
        Inventory inv = new Inventory();
        int[] breadinv;
        int[] meatinv;
        int[] cheeseinv;
        int[] otherinv;
        bool[] breadBool;
        bool[] meatBool;
        bool[] cheeseBool;
        bool[] otherBool;
        bool AddSub = true;


        public frmStart()
        {
            InitializeComponent();
            breadinv = inv.GetBreadInventory();
            meatinv = inv.GetMeatInventory();
            cheeseinv = inv.GetCheeseInventory();
            otherinv = inv.getOtherInventory();
            breadBool = inv.getBreadBool();
            meatBool = inv.getMeatBool();
            cheeseBool = inv.getCheeseBool();
            otherBool = inv.getOtherBool();
        }

        private void btnMakeSandwich_Click(object sender, EventArgs e)
        {
            
            plOrderSub.Visible = true;
            tbMonth.Text = Convert.ToString(DateTime.Now.Month);
            tbYear.Text = Convert.ToString(DateTime.Now.Year);

            rtbStock.SelectionAlignment = HorizontalAlignment.Center;

        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            
            plInventory.Visible = true;
            

            lblWhiteBread.Text = "0 - White Bread: " + breadinv[0];
            lblWheatBread.Text = "1 - Wheat Bread: " + breadinv[1];
            lblToastedWhiteBread.Text = "2 - Toasted White Bread: " + breadinv[2];
            lblToastedWheatBread.Text = "3 - Toasted Wheat Bread: " + breadinv[3];
            lblRyeBread.Text = "4 - Rye Bread: " + breadinv[4];
            lblMultigrainBread.Text = "5 - Multigrain Bread: " + breadinv[5];

            lblRoastBeef.Text = "0 - Roast Beef: " + meatinv[0];
            lblHam.Text = "1 - Ham: " + meatinv[1];
            lblChicken.Text = "2 - Chicken: " + meatinv[2];
            lblPepperoni.Text = "3 - Pepperoni: " + meatinv[3];
            lblTurkey.Text = "4 - Turkey: " + meatinv[4];
            lblMortadella.Text = "5 - Mortadella: " + meatinv[5];

            lblCheddar.Text = "0 - Cheddar: " + cheeseinv[0];
            lblMozzarella.Text = "1 - Mozzarella: " + cheeseinv[1];
            lblSwiss.Text = "2 - Swiss: " + cheeseinv[2];
            lblParmesan.Text = "3 - Parmesan: " + cheeseinv[3];
            lblAmerican.Text = "4 - American: " + cheeseinv[4];
            lblMuenster.Text = "5 - Muenster: " + cheeseinv[5];

            lblLettuce.Text = "0 - Lettuce: " + otherinv[0];
            lblMushrooms.Text = "1 - Mushrooms: " + otherinv[1];
            lblOlives.Text = "2 - Olives: " + otherinv[2];
            lblGuacamole.Text = "3 - Guacamole: " + otherinv[3];
            lblAvocado.Text = "4 - Avocado: " + otherinv[4];
            lblPeppers.Text = "5 - Peppers: " + otherinv[5];

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSandwichPageBack_Click(object sender, EventArgs e)
        {
            plOrderSub.Visible = false;
        }

        private void btnNewSandwich_Click(object sender, EventArgs e)
        {
            

            bool StockRanOut = false;


            if (rbWhiteBread.Checked && breadBool[0])
            {
                sm.assignBread(rbWhiteBread.Text);
                breadinv[0] -= 1;
            }
            else if (rbWhiteBread.Checked && breadBool[0] == false)
            {
                rbWhiteBread.Enabled = false;
                StockRanOut = true;
            }
            else if (rbWhiteBread.Checked && breadBool[0] == false)
            {
                rbWhiteBread.Enabled = false;
            }

            AddSub = true;
            if (sm.breadPrice(sm.getBreadType(), false) == 0)
            {
                AddSub = false;
            }
            else
            {
                AddSub = true;
            }


            if (rbWheatBread.Checked && breadBool[1])
            {
                sm.assignBread(rbWheatBread.Text);
                breadinv[1] -= 1;
            }
            else if (rbWheatBread.Checked && breadBool[1] == false)
            {
                rbWheatBread.Enabled = false;
                StockRanOut = true;
            }
            else if ( breadBool[1] == false)
            {
                rbWheatBread.Enabled = false;
            }
  


            if (rbToastedWhite.Checked && breadBool[2])
            {
                sm.assignBread(rbToastedWhite.Text);
                breadinv[2] -= 1;
            }
            else if (rbToastedWhite.Checked && breadBool[2] == false)
            {
                rbToastedWhite.Enabled = false;
                StockRanOut = true;
            }
            else if (breadBool[2] == false)
            {
                rbToastedWhite.Enabled = false;
            }
 


            if (rbToastedWheat.Checked && breadBool[3])
            {
                sm.assignBread(rbToastedWheat.Text);

                breadinv[3] -= 1;
            }
            else if (rbToastedWheat.Checked && breadBool[3] == false)
            {
                rbToastedWheat.Enabled = false;
                StockRanOut = true;
            }
            else if (breadBool[3] == false)
            {
                rbToastedWheat.Enabled = false;
            }



            if (rbRyeBread.Checked && breadBool[4])
            {
                sm.assignBread(rbRyeBread.Text);
                breadinv[4] -= 1;
            }
            else if (rbRyeBread.Checked && breadBool[4] == false)
            {
                rbRyeBread.Enabled = false;
                StockRanOut = true;
            }
            else if (breadBool[4] == false)
            {
                rbRyeBread.Enabled = false;
            }
 


            if (rbMultigrainBread.Checked && breadBool[5])
            {
                sm.assignBread(rbMultigrainBread.Text);
                breadinv[5] -= 1;
            }
            else if (rbMultigrainBread.Checked && breadBool[5] == false)
            {
                rbMultigrainBread.Enabled = false;
                StockRanOut = true;
            }
            else if (breadBool[5] == false)
            {
                rbMultigrainBread.Enabled = false;
            }



            if (cbRoast.Checked && meatBool[0] && AddSub)
            {
                sm.addMeat(cbRoast.Text);
                meatinv[0] -= 1;
            }
            else if (cbRoast.Checked && meatBool[0] == false)
            {
                cbRoast.Enabled = false;
                StockRanOut = true;
            }
            else if (meatBool[0] == false)
            {
                cbRoast.Enabled = false;
            }
  


            if (cbHam.Checked && meatBool[1] && AddSub)
            {
                sm.addMeat(cbHam.Text);
                meatinv[1] -= 1;
            }
            else if (cbHam.Checked && meatBool[1] == false)
            {
                cbHam.Enabled = false;
                StockRanOut = true;
            }
            else if (meatBool[1] == false)
            {
                cbHam.Enabled = false;
            }
     


            if (cbChicken.Checked && meatBool[2] && AddSub)
            {
                sm.addMeat(cbChicken.Text);
                meatinv[2] -= 1;
            }
            else if (cbChicken.Checked && meatBool[2] == false)
            {
                cbChicken.Enabled = false;
                StockRanOut = true;
            }
            else if (meatBool[2] == false)
            {
                cbChicken.Enabled = false;
            }



            if (cbPepperoni.Checked && meatBool[3] && AddSub)
            {
                sm.addMeat(cbPepperoni.Text);
                meatinv[3] -= 1;
            }
            else if (cbPepperoni.Checked && meatBool[3] == false)
            {
                cbPepperoni.Enabled = false;
                StockRanOut = true;
            }
            else if (meatBool[3] == false)
            {
                cbPepperoni.Enabled = false;
            }



            if (cbTurkey.Checked && meatBool[4] && AddSub)
            {
                sm.addMeat(cbTurkey.Text);
                meatinv[4] -= 1;
            }
            else if (cbTurkey.Checked && meatBool[4] == false)
            {
                cbTurkey.Enabled = false;
                StockRanOut = true;
            }
            else if (meatBool[4] == false)
            {
                cbTurkey.Enabled = false;
            }
  


            if (cbMortadella.Checked && meatBool[5] && AddSub)
            {
                sm.addMeat(cbMortadella.Text);
                meatinv[5] -= 1;
            }
            else if (cbMortadella.Checked && meatBool[5] == false)
            {
                cbMortadella.Enabled = false;
                StockRanOut = true;
            }
            else if (meatBool[5] == false)
            {
                cbMortadella.Enabled = false;
            }
 


            if (cbChedder.Checked && cheeseBool[0] && AddSub)
            {
                sm.addCheese(cbChedder.Text);
                cheeseinv[0] -= 1;
            }
            else if (cbChedder.Checked && cheeseBool[0] == false)
            {
                cbChedder.Enabled = false;
                StockRanOut = true;
            }
            else if (cheeseBool[0] == false)
            {
                cbChedder.Enabled = false;
            }


            if (cbMozzarella.Checked && cheeseBool[1] && AddSub)
            {
                sm.addCheese(cbMozzarella.Text);
                cheeseinv[1] -= 1;
            }
            else if (cbMozzarella.Checked && cheeseBool[1] == false)
            {
                cbMozzarella.Enabled = false;
                StockRanOut = true;
            }
            else if (cheeseBool[1] == false)
            {
                cbMozzarella.Enabled = false;
            }


            if (cbSwiss.Checked && cheeseBool[2] && AddSub)
            {
                sm.addCheese(cbSwiss.Text);
                cheeseinv[2] -= 1;
            }
            else if (cbSwiss.Checked && cheeseBool[2] == false)
            {
                cbSwiss.Enabled = false;
                StockRanOut = true;
            }
            else if (cheeseBool[2] == false)
            {
                cbSwiss.Enabled = false;
            }



            if (cbParmesan.Checked && cheeseBool[3] && AddSub)
            {
                sm.addCheese(cbParmesan.Text);
                cheeseinv[3] -= 1;
            }
            else if (cbParmesan.Checked && cheeseBool[3] == false)
            {
                cbParmesan.Enabled = false;
                StockRanOut = true;
            }
            else if (cheeseBool[3] == false)
            {
                cbParmesan.Enabled = false;
            }
     


            if (cbAmerican.Checked && cheeseBool[4] && AddSub)
            {
                sm.addCheese(cbAmerican.Text);
                cheeseinv[4] -= 1;
            }
            else if (cbAmerican.Checked && cheeseBool[4] == false)
            {
                cbAmerican.Enabled = false;
                StockRanOut = true;
            }
            else if (cheeseBool[4] == false)
            {
                cbAmerican.Enabled = false;
            }
    


            if (cbMuenster.Checked && cheeseBool[5] && AddSub)
            {
                sm.addCheese(cbMuenster.Text);
                cheeseinv[5] -= 1;
            }
            else if (cbMuenster.Checked && cheeseBool[5] == false)
            {
                cbMuenster.Enabled = false;
                StockRanOut = true;
            }
            else if (cheeseBool[5] == false)
            {
                cbMuenster.Enabled = false;
            }



            if (cbLettuce.Checked && otherBool[0] && AddSub)
            {
                sm.addOther(cbLettuce.Text);
                otherinv[0] -= 1;
            }
            else if (cbLettuce.Checked && otherBool[0] == false)
            {
                cbLettuce.Enabled = false;
                StockRanOut = true;
            }
            else if (otherBool[0] == false)
            {
                cbLettuce.Enabled = false;
            }
 


            if (cbMushrooms.Checked && otherBool[1] && AddSub)
            {
                sm.addOther(cbMushrooms.Text);
                otherinv[1] -= 1;
            }
            else if (cbMushrooms.Checked && otherBool[1] == false)
            {
                cbMushrooms.Enabled = false;
                StockRanOut = true;
            }
            else if (otherBool[1] == false)
            {
                cbMushrooms.Enabled = false;
            }
  


            if (cbOlives.Checked && otherBool[2] && AddSub)
            {
                sm.addOther(cbOlives.Text);
                otherinv[2] -= 1;
            }
            else if (cbOlives.Checked && otherBool[2] == false)
            {
                cbOlives.Enabled = false;
                StockRanOut = true;
            }
            else if (otherBool[2] == false)
            {
                cbOlives.Enabled = false;
            }
   


            if (cbGuacamole.Checked && otherBool[3] && AddSub)
            {
                sm.addOther(cbGuacamole.Text);
                otherinv[3] -= 1;
            }
            else if (cbGuacamole.Checked && otherBool[3] == false)
            {
                cbGuacamole.Enabled = false;
                StockRanOut = true;
            }
            else if (otherBool[3] == false)
            {
                cbGuacamole.Enabled = false;
            }
  


            if (cbAvocado.Checked && otherBool[4] && AddSub)
            {
                sm.addOther(cbAvocado.Text);
                otherinv[4] -= 1;
            }
            else if (cbAvocado.Checked && otherBool[4] == false)
            {
                cbAvocado.Enabled = false;
                StockRanOut = true;
            }
            else if (otherBool[4] == false)
            {
                cbAvocado.Enabled = false;
            }
 


            if (cbPeppers.Checked && otherBool[5] && AddSub)
            {
                sm.addOther(cbPeppers.Text);
                otherinv[5] -= 1;

            }
            else if (cbPeppers.Checked && otherBool[5] == false)
            {
                cbPeppers.Enabled = false;
                StockRanOut = true;
            }
            else if (otherBool[5] == false)
            {
                cbPeppers.Enabled = false;
            }




            rtbStock.Text = "";
            for (int i = 0; i < breadinv.Length; i++)
            {
                if (breadinv[i] <= 0)
                {
                    inv.setBreadToFalse(i);
                    rtbStock.AppendText("Sorry, we don't have " + inv.getBreadTypeStock(i) + " in stock at this time.\n");
                    
                }
                else
                {
                    inv.setBreadToTrue(i);
                }
            }

            for (int i = 0; i < meatinv.Length; i++)
            {
                if (meatinv[i] <= 0)
                {
                    inv.setMeatToFalse(i);
                    rtbStock.AppendText("Sorry, we don't have " + inv.getMeatTypeStock(i) + " in stock at this time.\n");

                }
                else
                {
                    inv.setMeatToTrue(i);

                }
            }

            for (int i = 0; i < cheeseinv.Length; i++)
            {
                if (cheeseinv[i] <= 0)
                {

                    inv.setCheeseToFalse(i);
                    rtbStock.AppendText("Sorry, we don't have " + inv.getCheeseTypeStock(i) + " in stock at this time.\n");
                }
                else
                {
                    inv.setCheeseToTrue(i);
                }
            }
            for (int i = 0; i < otherinv.Length; i++)
            {
                if (otherinv[i] <= 0)
                {
                    inv.setOtherToFalse(i);
                    rtbStock.AppendText("Sorry, we don't have " + inv.getOtherTypeStock(i) + " in stock at this time.\n");
                    
                }
                else
                {
                    inv.setOtherToTrue(i);
                }
            }

            if (!StockRanOut)
            {
                double subPrice = 0;
                if (AddSub == false)
                {
                    rtbSandwichOrder.AppendText("\nMake a sub before you click 'add sandwich'! ");

                }
                else
                {
                    
                    allSandwiches.Add(sm);
                    rtbSandwichOrder.AppendText("\n\nSandwich #" + numOfSandwich + sm.ToString());
                    numOfSandwich++;
                    sm = new Sandwich();
                    
                    foreach (Sandwich sub in allSandwiches)
                    {
                        subPrice = sub.getSandwichSubtotal();
                    }
                    subTotal += subPrice;
                    tax = subTotal * 0.045;
                    total = subTotal + tax;
                    lblSubtotal.Text = string.Format("Subtotal: {0:C}", subTotal);
                    lblTax.Text = string.Format("Tax: {0:C}", tax);
                    lblTotal.Text = string.Format("Total: {0:C}", total);
                }
            }
            else
            {
                rtbSandwichOrder.AppendText("\nSorry, Sandwich wasn't made due to stock. Try again.");
            }
            
                    rbMultigrainBread.Checked = false;
                    rbWheatBread.Checked = false;
                    rbWhiteBread.Checked = false;
                    rbToastedWheat.Checked = false;
                    rbToastedWhite.Checked = false;
                    rbRyeBread.Checked = false;
                    cbRoast.Checked = false;
                    cbHam.Checked = false;
                    cbChicken.Checked = false;
                    cbPepperoni.Checked = false;
                    cbTurkey.Checked = false;
                    cbMortadella.Checked = false;
                    cbChedder.Checked = false;
                    cbMozzarella.Checked = false;
                    cbSwiss.Checked = false;
                    cbParmesan.Checked = false;
                    cbAmerican.Checked = false;
                    cbMuenster.Checked = false;
                    cbLettuce.Checked = false;
                    cbMushrooms.Checked = false;
                    cbOlives.Checked = false;
                    cbGuacamole.Checked = false;
                    cbAvocado.Checked = false;
                    cbPeppers.Checked = false;

                    
                

        }
        private void btnRestart_Click(object sender, EventArgs e)
        {
            plEnjoy.Visible = false;
            numOfSandwich = 1;
            allSandwiches.Clear();
            rtbSandwichOrder.Text = "Sandwiches";
            lblSubtotal.Text = "Subtotal: $0:00";
            lblTax.Text = "Tax: $0:00";
            lblTotal.Text = "Tax: $0:00";
            rtbOrderResult.Text = " ";
            lblTotalResult.Text = "You will be charged $0:00. When ready enter in your information and click Submit and Pay.";
            btnCheckout.Visible = true;
            subTotal = 0;
            tax = 0;
            total = 0;

            rbMultigrainBread.Checked = false;
            rbWheatBread.Checked = false;
            rbWhiteBread.Checked = false;
            rbToastedWheat.Checked = false;
            rbToastedWhite.Checked = false;
            rbRyeBread.Checked = false;
            cbRoast.Checked = false;
            cbHam.Checked = false;
            cbChicken.Checked = false;
            cbPepperoni.Checked = false;
            cbTurkey.Checked = false;
            cbMortadella.Checked = false;
            cbChedder.Checked = false;
            cbMozzarella.Checked = false;
            cbSwiss.Checked = false;
            cbParmesan.Checked = false;
            cbAmerican.Checked = false;
            cbMuenster.Checked = false;
            cbLettuce.Checked = false;
            cbMushrooms.Checked = false;
            cbOlives.Checked = false;
            cbGuacamole.Checked = false;
            cbAvocado.Checked = false;
            cbPeppers.Checked = false;

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            invalidCounter = 0;
            plCheckout.Visible = true;
            btnCheckout.Visible = false;
            rtbOrderResult.Text = "";
            rtbOrderResult.AppendText("YOUR ORDER\n\n");
            int counter = 0;
            foreach (Sandwich sub in allSandwiches)
            {
                counter++;
                rtbOrderResult.AppendText(string.Format("Sandwich #{0} - price: {1:C}\n\n", counter, sub.getSandwichSubtotal()));
            }

            lblTotalResult.Text = string.Format("You will be charged {0:C}. When ready enter in information and click Submit and Pay", total);
        }

        private void btnBackToCustomize_Click(object sender, EventArgs e)
        {
            plCheckout.Visible = false;
            btnCheckout.Visible = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            bool correctData = true;
            string firstDigits = "";
            int numFirstDigits = 0;
            invalidCounter++;


            if (tbCreditCardNumber.Text.Length < 16 || tbCreditCardNumber.Text.Length > 16)
            {
                MessageBox.Show("You need to enter correct input for your credit card number! There needs to be exactly 16 numbers.");
                correctData = false;
            }
            else
            {

                firstDigits = tbCreditCardNumber.Text.Substring(0, 4);
                numFirstDigits = Convert.ToInt32(firstDigits);

                if (numFirstDigits == 1298 || numFirstDigits == 1267 || numFirstDigits == 4512 || numFirstDigits == 4567 || numFirstDigits == 8901 || numFirstDigits == 8933)
                {
        
                }
                else
                {
                    MessageBox.Show("You need to enter correct input for your credit card number! The first four digits are not correct.");
                    correctData = false;
                }

                
                
            }

            
            if (tbSecurityCode.Text.Length != 3)
            {
                MessageBox.Show("You need to enter correct input for your security code! There needs to be exactly 3 numbers.");
                correctData = false;
            }

            if (Convert.ToInt32(tbYear.Text) == DateTime.Now.Year)
            {
                if (tbMonth.Text.Length < 1 || tbMonth.Text.Length > 2 || Convert.ToInt32(tbMonth.Text) < DateTime.Now.Month || Convert.ToInt32(tbMonth.Text) > 12)
                {
                    MessageBox.Show("You need to enter correct input for the month!");

                    correctData = false;
                }
            }
            
            if (Convert.ToInt32(tbYear.Text) < DateTime.Now.Year)
            {
                MessageBox.Show("You need to enter correct input for the year!");
                correctData = false;
            }
            if (invalidCounter > 3)
            {
                invalidCounter = 0;
                MessageBox.Show("We're sorry, your order has been canceled due to, to many invalid entrys. Please come back again.");
                numOfSandwich = 1;
                plCheckout.Visible = false;
                plOrderSub.Visible = false;
                rtbSandwichOrder.Text = "Sandwiches";
                lblSubtotal.Text = "Subtotal: $0:00";
                lblTax.Text = "Tax: $0:00";
                lblTotal.Text = "Tax: $0:00";
                rtbOrderResult.Text = " ";
                lblTotalResult.Text = "You will be charged $0:00. When ready enter in your information and click Submit and Pay.";
                tbCreditCardNumber.Text = "";
                tbSecurityCode.Text = "";
                tbMonth.Text = Convert.ToString(DateTime.Now.Month);
                tbYear.Text = Convert.ToString(DateTime.Now.Year);
                subTotal = 0;
                tax = 0;
                total = 0;
                allSandwiches.Clear();
                btnCheckout.Visible = true;
                correctData = false;
            }

            if (correctData == true)
            {
                plEnjoy.Visible = true;
            }
        }

        private void btnExit2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReturnToMenu_Click(object sender, EventArgs e)
        {
            plEnjoy.Visible = false;
            numOfSandwich = 1;
            plCheckout.Visible = false;
            plOrderSub.Visible = false;
            rtbSandwichOrder.Text = "Sandwiches";
            lblSubtotal.Text = "Subtotal: $0:00";
            lblTax.Text = "Tax: $0:00";
            lblTotal.Text = "Tax: $0:00";
            rtbOrderResult.Text = " ";
            lblTotalResult.Text = "You will be charged $0:00. When ready enter in your information and click Submit and Pay.";
            tbCreditCardNumber.Text = "";
            tbSecurityCode.Text = "";
            tbMonth.Text = Convert.ToString( DateTime.Now.Month );
            tbYear.Text = Convert.ToString(DateTime.Now.Year);
            subTotal = 0;
            tax = 0;
            total = 0;
            allSandwiches.Clear();
            btnCheckout.Visible = true;
        }

        private void btnRestockBread_Click(object sender, EventArgs e)
        {
            inv.RestockBread();
            for (int i = 0; i < breadBool.Length; i++)
            {
                breadBool[i] = true;
            }
            rbWhiteBread.Enabled = true;
            rbWheatBread.Enabled = true;
            rbToastedWhite.Enabled = true;
            rbToastedWheat.Enabled = true;
            rbRyeBread.Enabled = true;
            rbMultigrainBread.Enabled = true;
            lblWhiteBread.Text = "0 - White Bread: " + breadinv[0];
            lblWheatBread.Text = "1 - Wheat Bread: " + breadinv[1];
            lblToastedWhiteBread.Text = "2 - Toasted White Bread: " + breadinv[2];
            lblToastedWheatBread.Text = "3 - Toasted Wheat Bread: " + breadinv[3];
            lblRyeBread.Text = "4 - Rye Bread: " + breadinv[4];
            lblMultigrainBread.Text = "5 - Multigrain Bread: " + breadinv[5];
        }

        private void btnRestockMeat_Click(object sender, EventArgs e)
        {
            inv.RestockMeat();
            for (int i = 0; i < meatBool.Length; i++)
            {
                meatBool[i] = true;
            }
            cbRoast.Enabled = true;
            cbHam.Enabled = true;
            cbChicken.Enabled = true;
            cbPepperoni.Enabled = true;
            cbTurkey.Enabled = true;
            cbMortadella.Enabled = true;
            lblRoastBeef.Text = "0 - Roast Beef: " + meatinv[0];
            lblHam.Text = "1 - Ham: " + meatinv[1];
            lblChicken.Text = "2 - Chicken: " + meatinv[2];
            lblPepperoni.Text = "3 - Pepperoni: " + meatinv[3];
            lblTurkey.Text = "4 - Turkey: " + meatinv[4];
            lblMortadella.Text = "5 - Mortadella: " + meatinv[5];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            plInventory.Visible = false;
        }

        private void btnRestockCheese_Click(object sender, EventArgs e)
        {
            inv.RestockCheese();
            for (int i = 0; i < cheeseBool.Length; i++)
            {
                cheeseBool[i] = true;
            }
            cbChedder.Enabled = true;
            cbMozzarella.Enabled = true;
            cbSwiss.Enabled = true;
            cbParmesan.Enabled = true;
            cbAmerican.Enabled = true;
            cbMuenster.Enabled = true;
            lblCheddar.Text = "0 - Cheddar: " + cheeseinv[0];
            lblMozzarella.Text = "1 - Mozzarella: " + cheeseinv[1];
            lblSwiss.Text = "2 - Swiss: " + cheeseinv[2];
            lblParmesan.Text = "3 - Parmesan: " + cheeseinv[3];
            lblAmerican.Text = "4 - American: " + cheeseinv[4];
            lblMuenster.Text = "5 - Muenster: " + cheeseinv[5];
        }

        private void btnRestockOther_Click(object sender, EventArgs e)
        {
            inv.RestockOther();
            for (int i = 0; i < otherBool.Length; i++)
            {
                otherBool[i] = true;
            }
            cbLettuce.Enabled = true;
            cbMushrooms.Enabled = true;
            cbOlives.Enabled = true;
            cbGuacamole.Enabled = true;
            cbAvocado.Enabled = true;
            cbPeppers.Enabled = true;
            lblLettuce.Text = "0 - Lettuce: " + otherinv[0];
            lblMushrooms.Text = "1 - Mushrooms: " + otherinv[1];
            lblOlives.Text = "2 - Olives: " + otherinv[2];
            lblGuacamole.Text = "3 - Guacamole: " + otherinv[3];
            lblAvocado.Text = "4 - Avocado: " + otherinv[4];
            lblPeppers.Text = "5 - Peppers: " + otherinv[5];
        }





        //I don't need these methods, I thought I did at one point. I can't remove them because if it do it seems to mess up the whole form
        private void rbWhiteBread_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rbWheatBread_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rbToastedWheat_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rbToastedWhite_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rbRyeBread_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rbMultigrainBread_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void lblMakeAnother_Click(object sender, EventArgs e)
        {
        }

        private void cbRoast_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbChicken_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbTurkey_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbHam_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbPepperoni_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbMortadella_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbChedder_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbMozzarella_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbSwiss_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbParmesan_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbAmerican_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbMuenster_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbLettuce_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbMushrooms_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbOlives_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbGuacamole_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbAvocado_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbPeppers_CheckedChanged(object sender, EventArgs e)
        {
        }

    }
}
