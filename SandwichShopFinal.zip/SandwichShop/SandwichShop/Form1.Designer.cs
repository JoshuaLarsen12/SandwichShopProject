﻿namespace SandwichShop
{
    partial class frmStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.plOrderSub = new System.Windows.Forms.Panel();
            this.plCheckout = new System.Windows.Forms.Panel();
            this.plEnjoy = new System.Windows.Forms.Panel();
            this.btnReturnToMenu = new System.Windows.Forms.Button();
            this.btnExit2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblMonth = new System.Windows.Forms.Label();
            this.tbYear = new System.Windows.Forms.TextBox();
            this.tbMonth = new System.Windows.Forms.TextBox();
            this.lblTotalResult = new System.Windows.Forms.Label();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.tbSecurityCode = new System.Windows.Forms.TextBox();
            this.lblExpiration = new System.Windows.Forms.Label();
            this.tbCreditCardNumber = new System.Windows.Forms.TextBox();
            this.rtbOrderResult = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnBackToCustomize = new System.Windows.Forms.Button();
            this.rtbStock = new System.Windows.Forms.RichTextBox();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnNewSandwich = new System.Windows.Forms.Button();
            this.btnSandwichPageBack = new System.Windows.Forms.Button();
            this.lblSandwichTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblTaxAmount = new System.Windows.Forms.Label();
            this.lblLineSeperator = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.rtbSandwichOrder = new System.Windows.Forms.RichTextBox();
            this.tabSandwichPick = new System.Windows.Forms.TabControl();
            this.tabPageBread = new System.Windows.Forms.TabPage();
            this.rbMultigrainBread = new System.Windows.Forms.RadioButton();
            this.rbRyeBread = new System.Windows.Forms.RadioButton();
            this.rbToastedWhite = new System.Windows.Forms.RadioButton();
            this.rbToastedWheat = new System.Windows.Forms.RadioButton();
            this.rbWheatBread = new System.Windows.Forms.RadioButton();
            this.rbWhiteBread = new System.Windows.Forms.RadioButton();
            this.tabPageMeat = new System.Windows.Forms.TabPage();
            this.cbMortadella = new System.Windows.Forms.CheckBox();
            this.cbPepperoni = new System.Windows.Forms.CheckBox();
            this.cbTurkey = new System.Windows.Forms.CheckBox();
            this.cbHam = new System.Windows.Forms.CheckBox();
            this.cbChicken = new System.Windows.Forms.CheckBox();
            this.cbRoast = new System.Windows.Forms.CheckBox();
            this.tabPageCheese = new System.Windows.Forms.TabPage();
            this.cbMuenster = new System.Windows.Forms.CheckBox();
            this.cbAmerican = new System.Windows.Forms.CheckBox();
            this.cbParmesan = new System.Windows.Forms.CheckBox();
            this.cbSwiss = new System.Windows.Forms.CheckBox();
            this.cbMozzarella = new System.Windows.Forms.CheckBox();
            this.cbChedder = new System.Windows.Forms.CheckBox();
            this.tabPageOtherIngredients = new System.Windows.Forms.TabPage();
            this.cbLettuce = new System.Windows.Forms.CheckBox();
            this.cbAvocado = new System.Windows.Forms.CheckBox();
            this.cbGuacamole = new System.Windows.Forms.CheckBox();
            this.cbOlives = new System.Windows.Forms.CheckBox();
            this.cbMushrooms = new System.Windows.Forms.CheckBox();
            this.cbPeppers = new System.Windows.Forms.CheckBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblChoose = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnInventory = new System.Windows.Forms.Button();
            this.btnMakeSandwich = new System.Windows.Forms.Button();
            this.plInventory = new System.Windows.Forms.Panel();
            this.plOtherStock = new System.Windows.Forms.Panel();
            this.btnRestockOther = new System.Windows.Forms.Button();
            this.lblPeppers = new System.Windows.Forms.Label();
            this.lblAvocado = new System.Windows.Forms.Label();
            this.lblGuacamole = new System.Windows.Forms.Label();
            this.lblOlives = new System.Windows.Forms.Label();
            this.lblMushrooms = new System.Windows.Forms.Label();
            this.lblLettuce = new System.Windows.Forms.Label();
            this.lblOtherStockTitle = new System.Windows.Forms.Label();
            this.plCheeseStock = new System.Windows.Forms.Panel();
            this.btnRestockCheese = new System.Windows.Forms.Button();
            this.lblMuenster = new System.Windows.Forms.Label();
            this.lblAmerican = new System.Windows.Forms.Label();
            this.lblParmesan = new System.Windows.Forms.Label();
            this.lblSwiss = new System.Windows.Forms.Label();
            this.lblMozzarella = new System.Windows.Forms.Label();
            this.lblCheddar = new System.Windows.Forms.Label();
            this.lblCheeseStockTitle = new System.Windows.Forms.Label();
            this.plMeatStock = new System.Windows.Forms.Panel();
            this.btnRestockMeat = new System.Windows.Forms.Button();
            this.lblMortadella = new System.Windows.Forms.Label();
            this.lblTurkey = new System.Windows.Forms.Label();
            this.lblPepperoni = new System.Windows.Forms.Label();
            this.lblChicken = new System.Windows.Forms.Label();
            this.lblHam = new System.Windows.Forms.Label();
            this.lblRoastBeef = new System.Windows.Forms.Label();
            this.lblMeatStockTitle = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblInvetoryExplaination = new System.Windows.Forms.Label();
            this.plBreadStock = new System.Windows.Forms.Panel();
            this.btnRestockBread = new System.Windows.Forms.Button();
            this.lblMultigrainBread = new System.Windows.Forms.Label();
            this.lblRyeBread = new System.Windows.Forms.Label();
            this.lblToastedWheatBread = new System.Windows.Forms.Label();
            this.lblToastedWhiteBread = new System.Windows.Forms.Label();
            this.lblWheatBread = new System.Windows.Forms.Label();
            this.lblWhiteBread = new System.Windows.Forms.Label();
            this.lblBreadStockTitle = new System.Windows.Forms.Label();
            this.plOrderSub.SuspendLayout();
            this.plCheckout.SuspendLayout();
            this.plEnjoy.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabSandwichPick.SuspendLayout();
            this.tabPageBread.SuspendLayout();
            this.tabPageMeat.SuspendLayout();
            this.tabPageCheese.SuspendLayout();
            this.tabPageOtherIngredients.SuspendLayout();
            this.plInventory.SuspendLayout();
            this.plOtherStock.SuspendLayout();
            this.plCheeseStock.SuspendLayout();
            this.plMeatStock.SuspendLayout();
            this.plBreadStock.SuspendLayout();
            this.SuspendLayout();
            // 
            // plOrderSub
            // 
            this.plOrderSub.BackColor = System.Drawing.Color.PeachPuff;
            this.plOrderSub.Controls.Add(this.plCheckout);
            this.plOrderSub.Controls.Add(this.rtbStock);
            this.plOrderSub.Controls.Add(this.btnRestart);
            this.plOrderSub.Controls.Add(this.btnNewSandwich);
            this.plOrderSub.Controls.Add(this.btnSandwichPageBack);
            this.plOrderSub.Controls.Add(this.lblSandwichTitle);
            this.plOrderSub.Controls.Add(this.panel2);
            this.plOrderSub.Controls.Add(this.rtbSandwichOrder);
            this.plOrderSub.Controls.Add(this.tabSandwichPick);
            this.plOrderSub.Location = new System.Drawing.Point(12, 12);
            this.plOrderSub.Name = "plOrderSub";
            this.plOrderSub.Size = new System.Drawing.Size(776, 426);
            this.plOrderSub.TabIndex = 6;
            this.plOrderSub.Visible = false;
            // 
            // plCheckout
            // 
            this.plCheckout.BackColor = System.Drawing.Color.Silver;
            this.plCheckout.Controls.Add(this.plEnjoy);
            this.plCheckout.Controls.Add(this.lblYear);
            this.plCheckout.Controls.Add(this.lblMonth);
            this.plCheckout.Controls.Add(this.tbYear);
            this.plCheckout.Controls.Add(this.tbMonth);
            this.plCheckout.Controls.Add(this.lblTotalResult);
            this.plCheckout.Controls.Add(this.lblCardNumber);
            this.plCheckout.Controls.Add(this.lblCode);
            this.plCheckout.Controls.Add(this.tbSecurityCode);
            this.plCheckout.Controls.Add(this.lblExpiration);
            this.plCheckout.Controls.Add(this.tbCreditCardNumber);
            this.plCheckout.Controls.Add(this.rtbOrderResult);
            this.plCheckout.Controls.Add(this.button1);
            this.plCheckout.Controls.Add(this.btnBackToCustomize);
            this.plCheckout.Location = new System.Drawing.Point(3, 6);
            this.plCheckout.Name = "plCheckout";
            this.plCheckout.Size = new System.Drawing.Size(562, 417);
            this.plCheckout.TabIndex = 10;
            this.plCheckout.Visible = false;
            // 
            // plEnjoy
            // 
            this.plEnjoy.BackColor = System.Drawing.Color.YellowGreen;
            this.plEnjoy.Controls.Add(this.btnReturnToMenu);
            this.plEnjoy.Controls.Add(this.btnExit2);
            this.plEnjoy.Controls.Add(this.label1);
            this.plEnjoy.Location = new System.Drawing.Point(11, 7);
            this.plEnjoy.Name = "plEnjoy";
            this.plEnjoy.Size = new System.Drawing.Size(540, 405);
            this.plEnjoy.TabIndex = 14;
            this.plEnjoy.Visible = false;
            // 
            // btnReturnToMenu
            // 
            this.btnReturnToMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnToMenu.Location = new System.Drawing.Point(186, 196);
            this.btnReturnToMenu.Name = "btnReturnToMenu";
            this.btnReturnToMenu.Size = new System.Drawing.Size(149, 84);
            this.btnReturnToMenu.TabIndex = 2;
            this.btnReturnToMenu.Text = "Return to start menu";
            this.btnReturnToMenu.UseVisualStyleBackColor = true;
            this.btnReturnToMenu.Click += new System.EventHandler(this.btnReturnToMenu_Click);
            // 
            // btnExit2
            // 
            this.btnExit2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit2.Location = new System.Drawing.Point(205, 326);
            this.btnExit2.Name = "btnExit2";
            this.btnExit2.Size = new System.Drawing.Size(112, 66);
            this.btnExit2.TabIndex = 1;
            this.btnExit2.Text = "Exit";
            this.btnExit2.UseVisualStyleBackColor = true;
            this.btnExit2.Click += new System.EventHandler(this.btnExit2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(489, 184);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thanks for stopping by! Enjoy your subs! Please come again!";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(350, 399);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(29, 13);
            this.lblYear.TabIndex = 13;
            this.lblYear.Text = "Year";
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Location = new System.Drawing.Point(297, 399);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(37, 13);
            this.lblMonth.TabIndex = 12;
            this.lblMonth.Text = "Month";
            // 
            // tbYear
            // 
            this.tbYear.Location = new System.Drawing.Point(335, 377);
            this.tbYear.Name = "tbYear";
            this.tbYear.Size = new System.Drawing.Size(61, 20);
            this.tbYear.TabIndex = 11;
            this.tbYear.Text = "2018";
            this.tbYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMonth
            // 
            this.tbMonth.Location = new System.Drawing.Point(300, 377);
            this.tbMonth.Name = "tbMonth";
            this.tbMonth.Size = new System.Drawing.Size(28, 20);
            this.tbMonth.TabIndex = 10;
            this.tbMonth.Text = "1";
            this.tbMonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTotalResult
            // 
            this.lblTotalResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalResult.Location = new System.Drawing.Point(377, 97);
            this.lblTotalResult.Name = "lblTotalResult";
            this.lblTotalResult.Size = new System.Drawing.Size(182, 231);
            this.lblTotalResult.TabIndex = 9;
            this.lblTotalResult.Text = "You will be charged $0:00. When ready enter in your information and click Submit " +
    "and Pay.";
            // 
            // lblCardNumber
            // 
            this.lblCardNumber.AutoSize = true;
            this.lblCardNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardNumber.Location = new System.Drawing.Point(13, 350);
            this.lblCardNumber.Name = "lblCardNumber";
            this.lblCardNumber.Size = new System.Drawing.Size(149, 20);
            this.lblCardNumber.TabIndex = 8;
            this.lblCardNumber.Text = "Credit Card Number";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Location = new System.Drawing.Point(194, 355);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(73, 13);
            this.lblCode.TabIndex = 7;
            this.lblCode.Text = "Security Code";
            // 
            // tbSecurityCode
            // 
            this.tbSecurityCode.Location = new System.Drawing.Point(209, 374);
            this.tbSecurityCode.Name = "tbSecurityCode";
            this.tbSecurityCode.Size = new System.Drawing.Size(43, 20);
            this.tbSecurityCode.TabIndex = 6;
            this.tbSecurityCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblExpiration
            // 
            this.lblExpiration.AutoSize = true;
            this.lblExpiration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpiration.Location = new System.Drawing.Point(297, 355);
            this.lblExpiration.Name = "lblExpiration";
            this.lblExpiration.Size = new System.Drawing.Size(99, 16);
            this.lblExpiration.TabIndex = 5;
            this.lblExpiration.Text = "Expiration Date";
            // 
            // tbCreditCardNumber
            // 
            this.tbCreditCardNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCreditCardNumber.Location = new System.Drawing.Point(11, 375);
            this.tbCreditCardNumber.Name = "tbCreditCardNumber";
            this.tbCreditCardNumber.Size = new System.Drawing.Size(151, 22);
            this.tbCreditCardNumber.TabIndex = 3;
            this.tbCreditCardNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rtbOrderResult
            // 
            this.rtbOrderResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbOrderResult.Location = new System.Drawing.Point(133, 12);
            this.rtbOrderResult.Name = "rtbOrderResult";
            this.rtbOrderResult.Size = new System.Drawing.Size(238, 330);
            this.rtbOrderResult.TabIndex = 2;
            this.rtbOrderResult.Text = "";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(416, 331);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 74);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit and Pay";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnBackToCustomize
            // 
            this.btnBackToCustomize.Location = new System.Drawing.Point(11, 12);
            this.btnBackToCustomize.Name = "btnBackToCustomize";
            this.btnBackToCustomize.Size = new System.Drawing.Size(116, 42);
            this.btnBackToCustomize.TabIndex = 0;
            this.btnBackToCustomize.Text = "<--- Back to making sandwiches";
            this.btnBackToCustomize.UseVisualStyleBackColor = true;
            this.btnBackToCustomize.Click += new System.EventHandler(this.btnBackToCustomize_Click);
            // 
            // rtbStock
            // 
            this.rtbStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbStock.Location = new System.Drawing.Point(238, 234);
            this.rtbStock.Name = "rtbStock";
            this.rtbStock.ReadOnly = true;
            this.rtbStock.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rtbStock.Size = new System.Drawing.Size(299, 186);
            this.rtbStock.TabIndex = 10;
            this.rtbStock.Text = "";
            // 
            // btnRestart
            // 
            this.btnRestart.Location = new System.Drawing.Point(153, 385);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(75, 35);
            this.btnRestart.TabIndex = 9;
            this.btnRestart.Text = "Cancel order";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // btnNewSandwich
            // 
            this.btnNewSandwich.Location = new System.Drawing.Point(14, 385);
            this.btnNewSandwich.Name = "btnNewSandwich";
            this.btnNewSandwich.Size = new System.Drawing.Size(93, 35);
            this.btnNewSandwich.TabIndex = 8;
            this.btnNewSandwich.Text = "Add Sandwich";
            this.btnNewSandwich.UseVisualStyleBackColor = true;
            this.btnNewSandwich.Click += new System.EventHandler(this.btnNewSandwich_Click);
            // 
            // btnSandwichPageBack
            // 
            this.btnSandwichPageBack.Location = new System.Drawing.Point(14, 15);
            this.btnSandwichPageBack.Name = "btnSandwichPageBack";
            this.btnSandwichPageBack.Size = new System.Drawing.Size(137, 42);
            this.btnSandwichPageBack.TabIndex = 4;
            this.btnSandwichPageBack.Text = "<--- Cancel and go back to beginning";
            this.btnSandwichPageBack.UseVisualStyleBackColor = true;
            this.btnSandwichPageBack.Click += new System.EventHandler(this.btnSandwichPageBack_Click);
            // 
            // lblSandwichTitle
            // 
            this.lblSandwichTitle.AutoSize = true;
            this.lblSandwichTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSandwichTitle.Location = new System.Drawing.Point(268, 15);
            this.lblSandwichTitle.Name = "lblSandwichTitle";
            this.lblSandwichTitle.Size = new System.Drawing.Size(269, 31);
            this.lblSandwichTitle.TabIndex = 3;
            this.lblSandwichTitle.Text = "Make your sandwich!";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGray;
            this.panel2.Controls.Add(this.lblTaxAmount);
            this.panel2.Controls.Add(this.lblLineSeperator);
            this.panel2.Controls.Add(this.lblTotal);
            this.panel2.Controls.Add(this.lblTax);
            this.panel2.Controls.Add(this.lblSubtotal);
            this.panel2.Controls.Add(this.btnCheckout);
            this.panel2.Location = new System.Drawing.Point(568, 189);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 219);
            this.panel2.TabIndex = 2;
            // 
            // lblTaxAmount
            // 
            this.lblTaxAmount.AutoSize = true;
            this.lblTaxAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxAmount.Location = new System.Drawing.Point(22, 60);
            this.lblTaxAmount.Name = "lblTaxAmount";
            this.lblTaxAmount.Size = new System.Drawing.Size(37, 16);
            this.lblTaxAmount.TabIndex = 5;
            this.lblTaxAmount.Text = "4.5%";
            // 
            // lblLineSeperator
            // 
            this.lblLineSeperator.AutoSize = true;
            this.lblLineSeperator.Location = new System.Drawing.Point(40, 83);
            this.lblLineSeperator.Name = "lblLineSeperator";
            this.lblLineSeperator.Size = new System.Drawing.Size(157, 13);
            this.lblLineSeperator.TabIndex = 4;
            this.lblLineSeperator.Text = "_________________________";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(44, 126);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(126, 25);
            this.lblTotal.TabIndex = 3;
            this.lblTotal.Text = "Total: $0:00";
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.Location = new System.Drawing.Point(56, 53);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(114, 25);
            this.lblTax.TabIndex = 2;
            this.lblTax.Text = "Tax: $0:00";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtotal.Location = new System.Drawing.Point(3, 18);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(171, 29);
            this.lblSubtotal.TabIndex = 1;
            this.lblSubtotal.Text = "Subtotal: $0:00";
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(72, 173);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(125, 36);
            this.btnCheckout.TabIndex = 0;
            this.btnCheckout.Text = "Checkout ---->";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.button1_Click);
            // 
            // rtbSandwichOrder
            // 
            this.rtbSandwichOrder.BackColor = System.Drawing.Color.Gainsboro;
            this.rtbSandwichOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbSandwichOrder.Location = new System.Drawing.Point(14, 75);
            this.rtbSandwichOrder.Name = "rtbSandwichOrder";
            this.rtbSandwichOrder.ReadOnly = true;
            this.rtbSandwichOrder.Size = new System.Drawing.Size(214, 304);
            this.rtbSandwichOrder.TabIndex = 1;
            this.rtbSandwichOrder.Text = "Sandwiches";
            // 
            // tabSandwichPick
            // 
            this.tabSandwichPick.Controls.Add(this.tabPageBread);
            this.tabSandwichPick.Controls.Add(this.tabPageMeat);
            this.tabSandwichPick.Controls.Add(this.tabPageCheese);
            this.tabSandwichPick.Controls.Add(this.tabPageOtherIngredients);
            this.tabSandwichPick.Location = new System.Drawing.Point(234, 77);
            this.tabSandwichPick.Name = "tabSandwichPick";
            this.tabSandwichPick.SelectedIndex = 0;
            this.tabSandwichPick.Size = new System.Drawing.Size(303, 155);
            this.tabSandwichPick.TabIndex = 0;
            // 
            // tabPageBread
            // 
            this.tabPageBread.Controls.Add(this.rbMultigrainBread);
            this.tabPageBread.Controls.Add(this.rbRyeBread);
            this.tabPageBread.Controls.Add(this.rbToastedWhite);
            this.tabPageBread.Controls.Add(this.rbToastedWheat);
            this.tabPageBread.Controls.Add(this.rbWheatBread);
            this.tabPageBread.Controls.Add(this.rbWhiteBread);
            this.tabPageBread.Location = new System.Drawing.Point(4, 22);
            this.tabPageBread.Name = "tabPageBread";
            this.tabPageBread.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBread.Size = new System.Drawing.Size(295, 129);
            this.tabPageBread.TabIndex = 0;
            this.tabPageBread.Text = "Bread";
            this.tabPageBread.UseVisualStyleBackColor = true;
            // 
            // rbMultigrainBread
            // 
            this.rbMultigrainBread.AutoSize = true;
            this.rbMultigrainBread.Location = new System.Drawing.Point(159, 90);
            this.rbMultigrainBread.Name = "rbMultigrainBread";
            this.rbMultigrainBread.Size = new System.Drawing.Size(101, 17);
            this.rbMultigrainBread.TabIndex = 1;
            this.rbMultigrainBread.TabStop = true;
            this.rbMultigrainBread.Text = "Multigrain Bread";
            this.rbMultigrainBread.UseVisualStyleBackColor = true;
            this.rbMultigrainBread.CheckedChanged += new System.EventHandler(this.rbMultigrainBread_CheckedChanged);
            // 
            // rbRyeBread
            // 
            this.rbRyeBread.AutoSize = true;
            this.rbRyeBread.Location = new System.Drawing.Point(20, 90);
            this.rbRyeBread.Name = "rbRyeBread";
            this.rbRyeBread.Size = new System.Drawing.Size(75, 17);
            this.rbRyeBread.TabIndex = 1;
            this.rbRyeBread.TabStop = true;
            this.rbRyeBread.Text = "Rye Bread";
            this.rbRyeBread.UseVisualStyleBackColor = true;
            this.rbRyeBread.CheckedChanged += new System.EventHandler(this.rbRyeBread_CheckedChanged);
            // 
            // rbToastedWhite
            // 
            this.rbToastedWhite.AutoSize = true;
            this.rbToastedWhite.Location = new System.Drawing.Point(159, 55);
            this.rbToastedWhite.Name = "rbToastedWhite";
            this.rbToastedWhite.Size = new System.Drawing.Size(126, 17);
            this.rbToastedWhite.TabIndex = 0;
            this.rbToastedWhite.TabStop = true;
            this.rbToastedWhite.Text = "Toasted White Bread";
            this.rbToastedWhite.UseVisualStyleBackColor = true;
            this.rbToastedWhite.CheckedChanged += new System.EventHandler(this.rbToastedWhite_CheckedChanged);
            // 
            // rbToastedWheat
            // 
            this.rbToastedWheat.AutoSize = true;
            this.rbToastedWheat.Location = new System.Drawing.Point(20, 55);
            this.rbToastedWheat.Name = "rbToastedWheat";
            this.rbToastedWheat.Size = new System.Drawing.Size(130, 17);
            this.rbToastedWheat.TabIndex = 0;
            this.rbToastedWheat.TabStop = true;
            this.rbToastedWheat.Text = "Toasted Wheat Bread";
            this.rbToastedWheat.UseVisualStyleBackColor = true;
            this.rbToastedWheat.CheckedChanged += new System.EventHandler(this.rbToastedWheat_CheckedChanged);
            // 
            // rbWheatBread
            // 
            this.rbWheatBread.AutoSize = true;
            this.rbWheatBread.Location = new System.Drawing.Point(159, 20);
            this.rbWheatBread.Name = "rbWheatBread";
            this.rbWheatBread.Size = new System.Drawing.Size(88, 17);
            this.rbWheatBread.TabIndex = 0;
            this.rbWheatBread.TabStop = true;
            this.rbWheatBread.Text = "Wheat Bread";
            this.rbWheatBread.UseVisualStyleBackColor = true;
            this.rbWheatBread.CheckedChanged += new System.EventHandler(this.rbWheatBread_CheckedChanged);
            // 
            // rbWhiteBread
            // 
            this.rbWhiteBread.AutoSize = true;
            this.rbWhiteBread.Location = new System.Drawing.Point(20, 20);
            this.rbWhiteBread.Name = "rbWhiteBread";
            this.rbWhiteBread.Size = new System.Drawing.Size(84, 17);
            this.rbWhiteBread.TabIndex = 0;
            this.rbWhiteBread.TabStop = true;
            this.rbWhiteBread.Text = "White Bread";
            this.rbWhiteBread.UseVisualStyleBackColor = true;
            this.rbWhiteBread.CheckedChanged += new System.EventHandler(this.rbWhiteBread_CheckedChanged);
            // 
            // tabPageMeat
            // 
            this.tabPageMeat.Controls.Add(this.cbMortadella);
            this.tabPageMeat.Controls.Add(this.cbPepperoni);
            this.tabPageMeat.Controls.Add(this.cbTurkey);
            this.tabPageMeat.Controls.Add(this.cbHam);
            this.tabPageMeat.Controls.Add(this.cbChicken);
            this.tabPageMeat.Controls.Add(this.cbRoast);
            this.tabPageMeat.Location = new System.Drawing.Point(4, 22);
            this.tabPageMeat.Name = "tabPageMeat";
            this.tabPageMeat.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMeat.Size = new System.Drawing.Size(295, 129);
            this.tabPageMeat.TabIndex = 1;
            this.tabPageMeat.Text = "Meat";
            this.tabPageMeat.UseVisualStyleBackColor = true;
            // 
            // cbMortadella
            // 
            this.cbMortadella.AutoSize = true;
            this.cbMortadella.Location = new System.Drawing.Point(168, 87);
            this.cbMortadella.Name = "cbMortadella";
            this.cbMortadella.Size = new System.Drawing.Size(75, 17);
            this.cbMortadella.TabIndex = 0;
            this.cbMortadella.Text = "Mortadella";
            this.cbMortadella.UseVisualStyleBackColor = true;
            this.cbMortadella.CheckedChanged += new System.EventHandler(this.cbMortadella_CheckedChanged);
            // 
            // cbPepperoni
            // 
            this.cbPepperoni.AutoSize = true;
            this.cbPepperoni.Location = new System.Drawing.Point(168, 54);
            this.cbPepperoni.Name = "cbPepperoni";
            this.cbPepperoni.Size = new System.Drawing.Size(74, 17);
            this.cbPepperoni.TabIndex = 0;
            this.cbPepperoni.Text = "Pepperoni";
            this.cbPepperoni.UseVisualStyleBackColor = true;
            this.cbPepperoni.CheckedChanged += new System.EventHandler(this.cbPepperoni_CheckedChanged);
            // 
            // cbTurkey
            // 
            this.cbTurkey.AutoSize = true;
            this.cbTurkey.Location = new System.Drawing.Point(24, 87);
            this.cbTurkey.Name = "cbTurkey";
            this.cbTurkey.Size = new System.Drawing.Size(59, 17);
            this.cbTurkey.TabIndex = 0;
            this.cbTurkey.Text = "Turkey";
            this.cbTurkey.UseVisualStyleBackColor = true;
            this.cbTurkey.CheckedChanged += new System.EventHandler(this.cbTurkey_CheckedChanged);
            // 
            // cbHam
            // 
            this.cbHam.AutoSize = true;
            this.cbHam.Location = new System.Drawing.Point(168, 18);
            this.cbHam.Name = "cbHam";
            this.cbHam.Size = new System.Drawing.Size(48, 17);
            this.cbHam.TabIndex = 0;
            this.cbHam.Text = "Ham";
            this.cbHam.UseVisualStyleBackColor = true;
            this.cbHam.CheckedChanged += new System.EventHandler(this.cbHam_CheckedChanged);
            // 
            // cbChicken
            // 
            this.cbChicken.AutoSize = true;
            this.cbChicken.Location = new System.Drawing.Point(24, 54);
            this.cbChicken.Name = "cbChicken";
            this.cbChicken.Size = new System.Drawing.Size(65, 17);
            this.cbChicken.TabIndex = 0;
            this.cbChicken.Text = "Chicken";
            this.cbChicken.UseVisualStyleBackColor = true;
            this.cbChicken.CheckedChanged += new System.EventHandler(this.cbChicken_CheckedChanged);
            // 
            // cbRoast
            // 
            this.cbRoast.AutoSize = true;
            this.cbRoast.Location = new System.Drawing.Point(24, 18);
            this.cbRoast.Name = "cbRoast";
            this.cbRoast.Size = new System.Drawing.Size(79, 17);
            this.cbRoast.TabIndex = 0;
            this.cbRoast.Text = "Roast Beef";
            this.cbRoast.UseVisualStyleBackColor = true;
            this.cbRoast.CheckedChanged += new System.EventHandler(this.cbRoast_CheckedChanged);
            // 
            // tabPageCheese
            // 
            this.tabPageCheese.Controls.Add(this.cbMuenster);
            this.tabPageCheese.Controls.Add(this.cbAmerican);
            this.tabPageCheese.Controls.Add(this.cbParmesan);
            this.tabPageCheese.Controls.Add(this.cbSwiss);
            this.tabPageCheese.Controls.Add(this.cbMozzarella);
            this.tabPageCheese.Controls.Add(this.cbChedder);
            this.tabPageCheese.Location = new System.Drawing.Point(4, 22);
            this.tabPageCheese.Name = "tabPageCheese";
            this.tabPageCheese.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCheese.Size = new System.Drawing.Size(295, 129);
            this.tabPageCheese.TabIndex = 2;
            this.tabPageCheese.Text = "Cheese";
            this.tabPageCheese.UseVisualStyleBackColor = true;
            // 
            // cbMuenster
            // 
            this.cbMuenster.AutoSize = true;
            this.cbMuenster.Location = new System.Drawing.Point(160, 88);
            this.cbMuenster.Name = "cbMuenster";
            this.cbMuenster.Size = new System.Drawing.Size(70, 17);
            this.cbMuenster.TabIndex = 0;
            this.cbMuenster.Text = "Muenster";
            this.cbMuenster.UseVisualStyleBackColor = true;
            this.cbMuenster.CheckedChanged += new System.EventHandler(this.cbMuenster_CheckedChanged);
            // 
            // cbAmerican
            // 
            this.cbAmerican.AutoSize = true;
            this.cbAmerican.Location = new System.Drawing.Point(24, 88);
            this.cbAmerican.Name = "cbAmerican";
            this.cbAmerican.Size = new System.Drawing.Size(70, 17);
            this.cbAmerican.TabIndex = 0;
            this.cbAmerican.Text = "American";
            this.cbAmerican.UseVisualStyleBackColor = true;
            this.cbAmerican.CheckedChanged += new System.EventHandler(this.cbAmerican_CheckedChanged);
            // 
            // cbParmesan
            // 
            this.cbParmesan.AutoSize = true;
            this.cbParmesan.Location = new System.Drawing.Point(160, 59);
            this.cbParmesan.Name = "cbParmesan";
            this.cbParmesan.Size = new System.Drawing.Size(73, 17);
            this.cbParmesan.TabIndex = 0;
            this.cbParmesan.Text = "Parmesan";
            this.cbParmesan.UseVisualStyleBackColor = true;
            this.cbParmesan.CheckedChanged += new System.EventHandler(this.cbParmesan_CheckedChanged);
            // 
            // cbSwiss
            // 
            this.cbSwiss.AutoSize = true;
            this.cbSwiss.Location = new System.Drawing.Point(24, 59);
            this.cbSwiss.Name = "cbSwiss";
            this.cbSwiss.Size = new System.Drawing.Size(53, 17);
            this.cbSwiss.TabIndex = 0;
            this.cbSwiss.Text = "Swiss";
            this.cbSwiss.UseVisualStyleBackColor = true;
            this.cbSwiss.CheckedChanged += new System.EventHandler(this.cbSwiss_CheckedChanged);
            // 
            // cbMozzarella
            // 
            this.cbMozzarella.AutoSize = true;
            this.cbMozzarella.Location = new System.Drawing.Point(160, 26);
            this.cbMozzarella.Name = "cbMozzarella";
            this.cbMozzarella.Size = new System.Drawing.Size(76, 17);
            this.cbMozzarella.TabIndex = 0;
            this.cbMozzarella.Text = "Mozzarella";
            this.cbMozzarella.UseVisualStyleBackColor = true;
            this.cbMozzarella.CheckedChanged += new System.EventHandler(this.cbMozzarella_CheckedChanged);
            // 
            // cbChedder
            // 
            this.cbChedder.AutoSize = true;
            this.cbChedder.Location = new System.Drawing.Point(24, 27);
            this.cbChedder.Name = "cbChedder";
            this.cbChedder.Size = new System.Drawing.Size(66, 17);
            this.cbChedder.TabIndex = 0;
            this.cbChedder.Text = "Cheddar";
            this.cbChedder.UseVisualStyleBackColor = true;
            this.cbChedder.CheckedChanged += new System.EventHandler(this.cbChedder_CheckedChanged);
            // 
            // tabPageOtherIngredients
            // 
            this.tabPageOtherIngredients.Controls.Add(this.cbLettuce);
            this.tabPageOtherIngredients.Controls.Add(this.cbAvocado);
            this.tabPageOtherIngredients.Controls.Add(this.cbGuacamole);
            this.tabPageOtherIngredients.Controls.Add(this.cbOlives);
            this.tabPageOtherIngredients.Controls.Add(this.cbMushrooms);
            this.tabPageOtherIngredients.Controls.Add(this.cbPeppers);
            this.tabPageOtherIngredients.Location = new System.Drawing.Point(4, 22);
            this.tabPageOtherIngredients.Name = "tabPageOtherIngredients";
            this.tabPageOtherIngredients.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOtherIngredients.Size = new System.Drawing.Size(295, 129);
            this.tabPageOtherIngredients.TabIndex = 3;
            this.tabPageOtherIngredients.Text = "Other Ingredients";
            this.tabPageOtherIngredients.UseVisualStyleBackColor = true;
            // 
            // cbLettuce
            // 
            this.cbLettuce.AutoSize = true;
            this.cbLettuce.Location = new System.Drawing.Point(24, 26);
            this.cbLettuce.Name = "cbLettuce";
            this.cbLettuce.Size = new System.Drawing.Size(62, 17);
            this.cbLettuce.TabIndex = 0;
            this.cbLettuce.Text = "Lettuce";
            this.cbLettuce.UseVisualStyleBackColor = true;
            this.cbLettuce.CheckedChanged += new System.EventHandler(this.cbLettuce_CheckedChanged);
            // 
            // cbAvocado
            // 
            this.cbAvocado.AutoSize = true;
            this.cbAvocado.Location = new System.Drawing.Point(24, 91);
            this.cbAvocado.Name = "cbAvocado";
            this.cbAvocado.Size = new System.Drawing.Size(69, 17);
            this.cbAvocado.TabIndex = 0;
            this.cbAvocado.Text = "Avocado";
            this.cbAvocado.UseVisualStyleBackColor = true;
            this.cbAvocado.CheckedChanged += new System.EventHandler(this.cbAvocado_CheckedChanged);
            // 
            // cbGuacamole
            // 
            this.cbGuacamole.AutoSize = true;
            this.cbGuacamole.Location = new System.Drawing.Point(160, 59);
            this.cbGuacamole.Name = "cbGuacamole";
            this.cbGuacamole.Size = new System.Drawing.Size(80, 17);
            this.cbGuacamole.TabIndex = 0;
            this.cbGuacamole.Text = "Guacamole";
            this.cbGuacamole.UseVisualStyleBackColor = true;
            this.cbGuacamole.CheckedChanged += new System.EventHandler(this.cbGuacamole_CheckedChanged);
            // 
            // cbOlives
            // 
            this.cbOlives.AutoSize = true;
            this.cbOlives.Location = new System.Drawing.Point(24, 59);
            this.cbOlives.Name = "cbOlives";
            this.cbOlives.Size = new System.Drawing.Size(55, 17);
            this.cbOlives.TabIndex = 0;
            this.cbOlives.Text = "Olives";
            this.cbOlives.UseVisualStyleBackColor = true;
            this.cbOlives.CheckedChanged += new System.EventHandler(this.cbOlives_CheckedChanged);
            // 
            // cbMushrooms
            // 
            this.cbMushrooms.AutoSize = true;
            this.cbMushrooms.Location = new System.Drawing.Point(160, 26);
            this.cbMushrooms.Name = "cbMushrooms";
            this.cbMushrooms.Size = new System.Drawing.Size(80, 17);
            this.cbMushrooms.TabIndex = 0;
            this.cbMushrooms.Text = "Mushrooms";
            this.cbMushrooms.UseVisualStyleBackColor = true;
            this.cbMushrooms.CheckedChanged += new System.EventHandler(this.cbMushrooms_CheckedChanged);
            // 
            // cbPeppers
            // 
            this.cbPeppers.AutoSize = true;
            this.cbPeppers.Location = new System.Drawing.Point(160, 92);
            this.cbPeppers.Name = "cbPeppers";
            this.cbPeppers.Size = new System.Drawing.Size(65, 17);
            this.cbPeppers.TabIndex = 0;
            this.cbPeppers.Text = "Peppers";
            this.cbPeppers.UseVisualStyleBackColor = true;
            this.cbPeppers.CheckedChanged += new System.EventHandler(this.cbPeppers_CheckedChanged);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(350, 401);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 37);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblChoose
            // 
            this.lblChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoose.Location = new System.Drawing.Point(294, 95);
            this.lblChoose.Name = "lblChoose";
            this.lblChoose.Size = new System.Drawing.Size(189, 31);
            this.lblChoose.TabIndex = 4;
            this.lblChoose.Text = "Choose an option";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(292, 27);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(183, 42);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Sub Shop";
            // 
            // btnInventory
            // 
            this.btnInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventory.Location = new System.Drawing.Point(299, 278);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(176, 79);
            this.btnInventory.TabIndex = 2;
            this.btnInventory.Text = "Check Inventory";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // btnMakeSandwich
            // 
            this.btnMakeSandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMakeSandwich.Location = new System.Drawing.Point(299, 165);
            this.btnMakeSandwich.Name = "btnMakeSandwich";
            this.btnMakeSandwich.Size = new System.Drawing.Size(176, 79);
            this.btnMakeSandwich.TabIndex = 1;
            this.btnMakeSandwich.Text = "Customize and buy sandwich";
            this.btnMakeSandwich.UseVisualStyleBackColor = true;
            this.btnMakeSandwich.Click += new System.EventHandler(this.btnMakeSandwich_Click);
            // 
            // plInventory
            // 
            this.plInventory.Controls.Add(this.plOtherStock);
            this.plInventory.Controls.Add(this.plCheeseStock);
            this.plInventory.Controls.Add(this.plMeatStock);
            this.plInventory.Controls.Add(this.button2);
            this.plInventory.Controls.Add(this.label2);
            this.plInventory.Controls.Add(this.lblInvetoryExplaination);
            this.plInventory.Controls.Add(this.plBreadStock);
            this.plInventory.Location = new System.Drawing.Point(12, 12);
            this.plInventory.Name = "plInventory";
            this.plInventory.Size = new System.Drawing.Size(776, 436);
            this.plInventory.TabIndex = 3;
            this.plInventory.Visible = false;
            // 
            // plOtherStock
            // 
            this.plOtherStock.BackColor = System.Drawing.Color.YellowGreen;
            this.plOtherStock.Controls.Add(this.btnRestockOther);
            this.plOtherStock.Controls.Add(this.lblPeppers);
            this.plOtherStock.Controls.Add(this.lblAvocado);
            this.plOtherStock.Controls.Add(this.lblGuacamole);
            this.plOtherStock.Controls.Add(this.lblOlives);
            this.plOtherStock.Controls.Add(this.lblMushrooms);
            this.plOtherStock.Controls.Add(this.lblLettuce);
            this.plOtherStock.Controls.Add(this.lblOtherStockTitle);
            this.plOtherStock.Location = new System.Drawing.Point(524, 16);
            this.plOtherStock.Name = "plOtherStock";
            this.plOtherStock.Size = new System.Drawing.Size(225, 255);
            this.plOtherStock.TabIndex = 4;
            // 
            // btnRestockOther
            // 
            this.btnRestockOther.Location = new System.Drawing.Point(74, 229);
            this.btnRestockOther.Name = "btnRestockOther";
            this.btnRestockOther.Size = new System.Drawing.Size(75, 23);
            this.btnRestockOther.TabIndex = 2;
            this.btnRestockOther.Text = "Restock";
            this.btnRestockOther.UseVisualStyleBackColor = true;
            this.btnRestockOther.Click += new System.EventHandler(this.btnRestockOther_Click);
            // 
            // lblPeppers
            // 
            this.lblPeppers.AutoSize = true;
            this.lblPeppers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeppers.Location = new System.Drawing.Point(27, 193);
            this.lblPeppers.Name = "lblPeppers";
            this.lblPeppers.Size = new System.Drawing.Size(98, 20);
            this.lblPeppers.TabIndex = 1;
            this.lblPeppers.Text = "5 - Peppers: ";
            // 
            // lblAvocado
            // 
            this.lblAvocado.AutoSize = true;
            this.lblAvocado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvocado.Location = new System.Drawing.Point(27, 166);
            this.lblAvocado.Name = "lblAvocado";
            this.lblAvocado.Size = new System.Drawing.Size(101, 20);
            this.lblAvocado.TabIndex = 1;
            this.lblAvocado.Text = "4 - Avocado: ";
            // 
            // lblGuacamole
            // 
            this.lblGuacamole.AutoSize = true;
            this.lblGuacamole.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuacamole.Location = new System.Drawing.Point(27, 137);
            this.lblGuacamole.Name = "lblGuacamole";
            this.lblGuacamole.Size = new System.Drawing.Size(121, 20);
            this.lblGuacamole.TabIndex = 1;
            this.lblGuacamole.Text = "3 - Guacamole: ";
            // 
            // lblOlives
            // 
            this.lblOlives.AutoSize = true;
            this.lblOlives.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOlives.Location = new System.Drawing.Point(27, 110);
            this.lblOlives.Name = "lblOlives";
            this.lblOlives.Size = new System.Drawing.Size(81, 20);
            this.lblOlives.TabIndex = 1;
            this.lblOlives.Text = "2 - Olives: ";
            // 
            // lblMushrooms
            // 
            this.lblMushrooms.AutoSize = true;
            this.lblMushrooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMushrooms.Location = new System.Drawing.Point(27, 81);
            this.lblMushrooms.Name = "lblMushrooms";
            this.lblMushrooms.Size = new System.Drawing.Size(122, 20);
            this.lblMushrooms.TabIndex = 1;
            this.lblMushrooms.Text = "1 - Mushrooms: ";
            // 
            // lblLettuce
            // 
            this.lblLettuce.AutoSize = true;
            this.lblLettuce.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLettuce.Location = new System.Drawing.Point(27, 52);
            this.lblLettuce.Name = "lblLettuce";
            this.lblLettuce.Size = new System.Drawing.Size(93, 20);
            this.lblLettuce.TabIndex = 1;
            this.lblLettuce.Text = "0 - Lettuce: ";
            // 
            // lblOtherStockTitle
            // 
            this.lblOtherStockTitle.AutoSize = true;
            this.lblOtherStockTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOtherStockTitle.Location = new System.Drawing.Point(65, 13);
            this.lblOtherStockTitle.Name = "lblOtherStockTitle";
            this.lblOtherStockTitle.Size = new System.Drawing.Size(94, 20);
            this.lblOtherStockTitle.TabIndex = 0;
            this.lblOtherStockTitle.Text = "Other Stock";
            // 
            // plCheeseStock
            // 
            this.plCheeseStock.BackColor = System.Drawing.Color.LemonChiffon;
            this.plCheeseStock.Controls.Add(this.btnRestockCheese);
            this.plCheeseStock.Controls.Add(this.lblMuenster);
            this.plCheeseStock.Controls.Add(this.lblAmerican);
            this.plCheeseStock.Controls.Add(this.lblParmesan);
            this.plCheeseStock.Controls.Add(this.lblSwiss);
            this.plCheeseStock.Controls.Add(this.lblMozzarella);
            this.plCheeseStock.Controls.Add(this.lblCheddar);
            this.plCheeseStock.Controls.Add(this.lblCheeseStockTitle);
            this.plCheeseStock.Location = new System.Drawing.Point(427, 278);
            this.plCheeseStock.Name = "plCheeseStock";
            this.plCheeseStock.Size = new System.Drawing.Size(338, 149);
            this.plCheeseStock.TabIndex = 4;
            // 
            // btnRestockCheese
            // 
            this.btnRestockCheese.Location = new System.Drawing.Point(116, 121);
            this.btnRestockCheese.Name = "btnRestockCheese";
            this.btnRestockCheese.Size = new System.Drawing.Size(75, 23);
            this.btnRestockCheese.TabIndex = 2;
            this.btnRestockCheese.Text = "Restock";
            this.btnRestockCheese.UseVisualStyleBackColor = true;
            this.btnRestockCheese.Click += new System.EventHandler(this.btnRestockCheese_Click);
            // 
            // lblMuenster
            // 
            this.lblMuenster.AutoSize = true;
            this.lblMuenster.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMuenster.Location = new System.Drawing.Point(209, 126);
            this.lblMuenster.Name = "lblMuenster";
            this.lblMuenster.Size = new System.Drawing.Size(102, 20);
            this.lblMuenster.TabIndex = 1;
            this.lblMuenster.Text = "5 - Muenster:";
            // 
            // lblAmerican
            // 
            this.lblAmerican.AutoSize = true;
            this.lblAmerican.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmerican.Location = new System.Drawing.Point(209, 82);
            this.lblAmerican.Name = "lblAmerican";
            this.lblAmerican.Size = new System.Drawing.Size(102, 20);
            this.lblAmerican.TabIndex = 1;
            this.lblAmerican.Text = "4 - American:";
            // 
            // lblParmesan
            // 
            this.lblParmesan.AutoSize = true;
            this.lblParmesan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParmesan.Location = new System.Drawing.Point(204, 40);
            this.lblParmesan.Name = "lblParmesan";
            this.lblParmesan.Size = new System.Drawing.Size(107, 20);
            this.lblParmesan.TabIndex = 1;
            this.lblParmesan.Text = "3 - Parmesan:";
            // 
            // lblSwiss
            // 
            this.lblSwiss.AutoSize = true;
            this.lblSwiss.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSwiss.Location = new System.Drawing.Point(12, 126);
            this.lblSwiss.Name = "lblSwiss";
            this.lblSwiss.Size = new System.Drawing.Size(76, 20);
            this.lblSwiss.TabIndex = 1;
            this.lblSwiss.Text = "2 - Swiss:";
            // 
            // lblMozzarella
            // 
            this.lblMozzarella.AutoSize = true;
            this.lblMozzarella.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozzarella.Location = new System.Drawing.Point(12, 82);
            this.lblMozzarella.Name = "lblMozzarella";
            this.lblMozzarella.Size = new System.Drawing.Size(111, 20);
            this.lblMozzarella.TabIndex = 1;
            this.lblMozzarella.Text = "1 - Mozzarella:";
            // 
            // lblCheddar
            // 
            this.lblCheddar.AutoSize = true;
            this.lblCheddar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheddar.Location = new System.Drawing.Point(12, 40);
            this.lblCheddar.Name = "lblCheddar";
            this.lblCheddar.Size = new System.Drawing.Size(96, 20);
            this.lblCheddar.TabIndex = 1;
            this.lblCheddar.Text = "0 - Cheddar:";
            // 
            // lblCheeseStockTitle
            // 
            this.lblCheeseStockTitle.AutoSize = true;
            this.lblCheeseStockTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheeseStockTitle.Location = new System.Drawing.Point(98, 5);
            this.lblCheeseStockTitle.Name = "lblCheeseStockTitle";
            this.lblCheeseStockTitle.Size = new System.Drawing.Size(109, 20);
            this.lblCheeseStockTitle.TabIndex = 0;
            this.lblCheeseStockTitle.Text = "Cheese Stock";
            // 
            // plMeatStock
            // 
            this.plMeatStock.BackColor = System.Drawing.Color.IndianRed;
            this.plMeatStock.Controls.Add(this.btnRestockMeat);
            this.plMeatStock.Controls.Add(this.lblMortadella);
            this.plMeatStock.Controls.Add(this.lblTurkey);
            this.plMeatStock.Controls.Add(this.lblPepperoni);
            this.plMeatStock.Controls.Add(this.lblChicken);
            this.plMeatStock.Controls.Add(this.lblHam);
            this.plMeatStock.Controls.Add(this.lblRoastBeef);
            this.plMeatStock.Controls.Add(this.lblMeatStockTitle);
            this.plMeatStock.Location = new System.Drawing.Point(66, 278);
            this.plMeatStock.Name = "plMeatStock";
            this.plMeatStock.Size = new System.Drawing.Size(333, 149);
            this.plMeatStock.TabIndex = 4;
            // 
            // btnRestockMeat
            // 
            this.btnRestockMeat.Location = new System.Drawing.Point(118, 123);
            this.btnRestockMeat.Name = "btnRestockMeat";
            this.btnRestockMeat.Size = new System.Drawing.Size(75, 23);
            this.btnRestockMeat.TabIndex = 2;
            this.btnRestockMeat.Text = "Restock";
            this.btnRestockMeat.UseVisualStyleBackColor = true;
            this.btnRestockMeat.Click += new System.EventHandler(this.btnRestockMeat_Click);
            // 
            // lblMortadella
            // 
            this.lblMortadella.AutoSize = true;
            this.lblMortadella.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMortadella.Location = new System.Drawing.Point(199, 123);
            this.lblMortadella.Name = "lblMortadella";
            this.lblMortadella.Size = new System.Drawing.Size(109, 20);
            this.lblMortadella.TabIndex = 1;
            this.lblMortadella.Text = "5 - Mortadella:";
            // 
            // lblTurkey
            // 
            this.lblTurkey.AutoSize = true;
            this.lblTurkey.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurkey.Location = new System.Drawing.Point(226, 80);
            this.lblTurkey.Name = "lblTurkey";
            this.lblTurkey.Size = new System.Drawing.Size(82, 20);
            this.lblTurkey.TabIndex = 1;
            this.lblTurkey.Text = "4 - Turkey:";
            // 
            // lblPepperoni
            // 
            this.lblPepperoni.AutoSize = true;
            this.lblPepperoni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPepperoni.Location = new System.Drawing.Point(201, 43);
            this.lblPepperoni.Name = "lblPepperoni";
            this.lblPepperoni.Size = new System.Drawing.Size(107, 20);
            this.lblPepperoni.TabIndex = 1;
            this.lblPepperoni.Text = "3 - Pepperoni:";
            // 
            // lblChicken
            // 
            this.lblChicken.AutoSize = true;
            this.lblChicken.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChicken.Location = new System.Drawing.Point(3, 121);
            this.lblChicken.Name = "lblChicken";
            this.lblChicken.Size = new System.Drawing.Size(92, 20);
            this.lblChicken.TabIndex = 1;
            this.lblChicken.Text = "2 - Chicken:";
            // 
            // lblHam
            // 
            this.lblHam.AutoSize = true;
            this.lblHam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHam.Location = new System.Drawing.Point(3, 86);
            this.lblHam.Name = "lblHam";
            this.lblHam.Size = new System.Drawing.Size(69, 20);
            this.lblHam.TabIndex = 1;
            this.lblHam.Text = "1 - Ham:";
            // 
            // lblRoastBeef
            // 
            this.lblRoastBeef.AutoSize = true;
            this.lblRoastBeef.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoastBeef.Location = new System.Drawing.Point(3, 47);
            this.lblRoastBeef.Name = "lblRoastBeef";
            this.lblRoastBeef.Size = new System.Drawing.Size(116, 20);
            this.lblRoastBeef.TabIndex = 1;
            this.lblRoastBeef.Text = "0 - Roast Beef:";
            // 
            // lblMeatStockTitle
            // 
            this.lblMeatStockTitle.AutoSize = true;
            this.lblMeatStockTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeatStockTitle.Location = new System.Drawing.Point(100, 7);
            this.lblMeatStockTitle.Name = "lblMeatStockTitle";
            this.lblMeatStockTitle.Size = new System.Drawing.Size(90, 20);
            this.lblMeatStockTitle.TabIndex = 0;
            this.lblMeatStockTitle.Text = "Meat Stock";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 54);
            this.button2.TabIndex = 3;
            this.button2.Text = "<--- Back to start menu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(338, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 39);
            this.label2.TabIndex = 2;
            this.label2.Text = "Inventory";
            // 
            // lblInvetoryExplaination
            // 
            this.lblInvetoryExplaination.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvetoryExplaination.Location = new System.Drawing.Point(339, 68);
            this.lblInvetoryExplaination.Name = "lblInvetoryExplaination";
            this.lblInvetoryExplaination.Size = new System.Drawing.Size(161, 182);
            this.lblInvetoryExplaination.TabIndex = 1;
            this.lblInvetoryExplaination.Text = "On the left of the product it shows the position that, that product is in. And on" +
    " the right is the quantity of that product";
            this.lblInvetoryExplaination.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // plBreadStock
            // 
            this.plBreadStock.BackColor = System.Drawing.Color.Wheat;
            this.plBreadStock.Controls.Add(this.btnRestockBread);
            this.plBreadStock.Controls.Add(this.lblMultigrainBread);
            this.plBreadStock.Controls.Add(this.lblRyeBread);
            this.plBreadStock.Controls.Add(this.lblToastedWheatBread);
            this.plBreadStock.Controls.Add(this.lblToastedWhiteBread);
            this.plBreadStock.Controls.Add(this.lblWheatBread);
            this.plBreadStock.Controls.Add(this.lblWhiteBread);
            this.plBreadStock.Controls.Add(this.lblBreadStockTitle);
            this.plBreadStock.Location = new System.Drawing.Point(91, 16);
            this.plBreadStock.Name = "plBreadStock";
            this.plBreadStock.Size = new System.Drawing.Size(227, 257);
            this.plBreadStock.TabIndex = 0;
            // 
            // btnRestockBread
            // 
            this.btnRestockBread.Location = new System.Drawing.Point(75, 230);
            this.btnRestockBread.Name = "btnRestockBread";
            this.btnRestockBread.Size = new System.Drawing.Size(75, 23);
            this.btnRestockBread.TabIndex = 2;
            this.btnRestockBread.Text = "Restock";
            this.btnRestockBread.UseVisualStyleBackColor = true;
            this.btnRestockBread.Click += new System.EventHandler(this.btnRestockBread_Click);
            // 
            // lblMultigrainBread
            // 
            this.lblMultigrainBread.AutoSize = true;
            this.lblMultigrainBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultigrainBread.Location = new System.Drawing.Point(17, 192);
            this.lblMultigrainBread.Name = "lblMultigrainBread";
            this.lblMultigrainBread.Size = new System.Drawing.Size(154, 20);
            this.lblMultigrainBread.TabIndex = 1;
            this.lblMultigrainBread.Text = "5 - Multigrain Bread: ";
            // 
            // lblRyeBread
            // 
            this.lblRyeBread.AutoSize = true;
            this.lblRyeBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRyeBread.Location = new System.Drawing.Point(17, 165);
            this.lblRyeBread.Name = "lblRyeBread";
            this.lblRyeBread.Size = new System.Drawing.Size(114, 20);
            this.lblRyeBread.TabIndex = 1;
            this.lblRyeBread.Text = "4 - Rye Bread: ";
            // 
            // lblToastedWheatBread
            // 
            this.lblToastedWheatBread.AutoSize = true;
            this.lblToastedWheatBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToastedWheatBread.Location = new System.Drawing.Point(17, 138);
            this.lblToastedWheatBread.Name = "lblToastedWheatBread";
            this.lblToastedWheatBread.Size = new System.Drawing.Size(195, 20);
            this.lblToastedWheatBread.TabIndex = 1;
            this.lblToastedWheatBread.Text = "3 - Toasted Wheat Bread: ";
            // 
            // lblToastedWhiteBread
            // 
            this.lblToastedWhiteBread.AutoSize = true;
            this.lblToastedWhiteBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToastedWhiteBread.Location = new System.Drawing.Point(17, 109);
            this.lblToastedWhiteBread.Name = "lblToastedWhiteBread";
            this.lblToastedWhiteBread.Size = new System.Drawing.Size(189, 20);
            this.lblToastedWhiteBread.TabIndex = 1;
            this.lblToastedWhiteBread.Text = "2 - Toasted White Bread: ";
            // 
            // lblWheatBread
            // 
            this.lblWheatBread.AutoSize = true;
            this.lblWheatBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWheatBread.Location = new System.Drawing.Point(17, 80);
            this.lblWheatBread.Name = "lblWheatBread";
            this.lblWheatBread.Size = new System.Drawing.Size(133, 20);
            this.lblWheatBread.TabIndex = 1;
            this.lblWheatBread.Text = "1 - Wheat Bread: ";
            // 
            // lblWhiteBread
            // 
            this.lblWhiteBread.AutoSize = true;
            this.lblWhiteBread.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhiteBread.Location = new System.Drawing.Point(17, 54);
            this.lblWhiteBread.Name = "lblWhiteBread";
            this.lblWhiteBread.Size = new System.Drawing.Size(127, 20);
            this.lblWhiteBread.TabIndex = 1;
            this.lblWhiteBread.Text = "0 - White Bread: ";
            // 
            // lblBreadStockTitle
            // 
            this.lblBreadStockTitle.AutoSize = true;
            this.lblBreadStockTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBreadStockTitle.Location = new System.Drawing.Point(64, 12);
            this.lblBreadStockTitle.Name = "lblBreadStockTitle";
            this.lblBreadStockTitle.Size = new System.Drawing.Size(97, 20);
            this.lblBreadStockTitle.TabIndex = 0;
            this.lblBreadStockTitle.Text = "Bread Stock";
            // 
            // frmStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(803, 455);
            this.Controls.Add(this.plInventory);
            this.Controls.Add(this.plOrderSub);
            this.Controls.Add(this.lblChoose);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnInventory);
            this.Controls.Add(this.btnMakeSandwich);
            this.Controls.Add(this.lblTitle);
            this.Name = "frmStart";
            this.Text = "Sub Shop";
            this.plOrderSub.ResumeLayout(false);
            this.plOrderSub.PerformLayout();
            this.plCheckout.ResumeLayout(false);
            this.plCheckout.PerformLayout();
            this.plEnjoy.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabSandwichPick.ResumeLayout(false);
            this.tabPageBread.ResumeLayout(false);
            this.tabPageBread.PerformLayout();
            this.tabPageMeat.ResumeLayout(false);
            this.tabPageMeat.PerformLayout();
            this.tabPageCheese.ResumeLayout(false);
            this.tabPageCheese.PerformLayout();
            this.tabPageOtherIngredients.ResumeLayout(false);
            this.tabPageOtherIngredients.PerformLayout();
            this.plInventory.ResumeLayout(false);
            this.plInventory.PerformLayout();
            this.plOtherStock.ResumeLayout(false);
            this.plOtherStock.PerformLayout();
            this.plCheeseStock.ResumeLayout(false);
            this.plCheeseStock.PerformLayout();
            this.plMeatStock.ResumeLayout(false);
            this.plMeatStock.PerformLayout();
            this.plBreadStock.ResumeLayout(false);
            this.plBreadStock.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel plOrderSub;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblLineSeperator;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblSubtotal;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.RichTextBox rtbSandwichOrder;
        private System.Windows.Forms.TabControl tabSandwichPick;
        private System.Windows.Forms.TabPage tabPageBread;
        private System.Windows.Forms.TabPage tabPageMeat;
        private System.Windows.Forms.TabPage tabPageCheese;
        private System.Windows.Forms.TabPage tabPageOtherIngredients;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblChoose;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Button btnMakeSandwich;
        private System.Windows.Forms.Label lblSandwichTitle;
        private System.Windows.Forms.RadioButton rbMultigrainBread;
        private System.Windows.Forms.RadioButton rbRyeBread;
        private System.Windows.Forms.RadioButton rbToastedWhite;
        private System.Windows.Forms.RadioButton rbToastedWheat;
        private System.Windows.Forms.RadioButton rbWheatBread;
        private System.Windows.Forms.RadioButton rbWhiteBread;
        private System.Windows.Forms.CheckBox cbMortadella;
        private System.Windows.Forms.CheckBox cbPepperoni;
        private System.Windows.Forms.CheckBox cbTurkey;
        private System.Windows.Forms.CheckBox cbHam;
        private System.Windows.Forms.CheckBox cbChicken;
        private System.Windows.Forms.CheckBox cbRoast;
        private System.Windows.Forms.CheckBox cbMuenster;
        private System.Windows.Forms.CheckBox cbAmerican;
        private System.Windows.Forms.CheckBox cbParmesan;
        private System.Windows.Forms.CheckBox cbSwiss;
        private System.Windows.Forms.CheckBox cbMozzarella;
        private System.Windows.Forms.CheckBox cbChedder;
        private System.Windows.Forms.CheckBox cbLettuce;
        private System.Windows.Forms.CheckBox cbAvocado;
        private System.Windows.Forms.CheckBox cbGuacamole;
        private System.Windows.Forms.CheckBox cbOlives;
        private System.Windows.Forms.CheckBox cbMushrooms;
        private System.Windows.Forms.CheckBox cbPeppers;
        private System.Windows.Forms.Button btnSandwichPageBack;
        private System.Windows.Forms.Button btnNewSandwich;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label lblTaxAmount;
        private System.Windows.Forms.Panel plCheckout;
        private System.Windows.Forms.Button btnBackToCustomize;
        private System.Windows.Forms.TextBox tbCreditCardNumber;
        private System.Windows.Forms.RichTextBox rtbOrderResult;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.TextBox tbSecurityCode;
        private System.Windows.Forms.Label lblExpiration;
        private System.Windows.Forms.Label lblTotalResult;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.TextBox tbYear;
        private System.Windows.Forms.TextBox tbMonth;
        private System.Windows.Forms.Panel plEnjoy;
        private System.Windows.Forms.Button btnExit2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnReturnToMenu;
        private System.Windows.Forms.Panel plInventory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblInvetoryExplaination;
        private System.Windows.Forms.Panel plBreadStock;
        private System.Windows.Forms.Label lblWheatBread;
        private System.Windows.Forms.Label lblWhiteBread;
        private System.Windows.Forms.Label lblBreadStockTitle;
        private System.Windows.Forms.Label lblRyeBread;
        private System.Windows.Forms.Label lblToastedWheatBread;
        private System.Windows.Forms.Label lblToastedWhiteBread;
        private System.Windows.Forms.Label lblMultigrainBread;
        private System.Windows.Forms.Button btnRestockBread;
        private System.Windows.Forms.Panel plMeatStock;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel plOtherStock;
        private System.Windows.Forms.Panel plCheeseStock;
        private System.Windows.Forms.Label lblRoastBeef;
        private System.Windows.Forms.Label lblMeatStockTitle;
        private System.Windows.Forms.Label lblHam;
        private System.Windows.Forms.Label lblChicken;
        private System.Windows.Forms.Label lblPepperoni;
        private System.Windows.Forms.Label lblMortadella;
        private System.Windows.Forms.Label lblTurkey;
        private System.Windows.Forms.Button btnRestockMeat;
        private System.Windows.Forms.Label lblMushrooms;
        private System.Windows.Forms.Label lblLettuce;
        private System.Windows.Forms.Label lblOtherStockTitle;
        private System.Windows.Forms.Label lblOlives;
        private System.Windows.Forms.Label lblGuacamole;
        private System.Windows.Forms.Label lblAvocado;
        private System.Windows.Forms.Button btnRestockOther;
        private System.Windows.Forms.Label lblPeppers;
        private System.Windows.Forms.Label lblCheddar;
        private System.Windows.Forms.Label lblCheeseStockTitle;
        private System.Windows.Forms.Label lblMozzarella;
        private System.Windows.Forms.Label lblSwiss;
        private System.Windows.Forms.Label lblParmesan;
        private System.Windows.Forms.Label lblMuenster;
        private System.Windows.Forms.Label lblAmerican;
        private System.Windows.Forms.Button btnRestockCheese;
        private System.Windows.Forms.RichTextBox rtbStock;
    }
}

