﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SandwichShop
{
    
    class Inventory
    {
        public Inventory()
        {

        }
        int[] breadInventory = new int[] { 2, 5, 3, 4, 6, 0 };
        int[] meatInventory = new int[] { 6, 2, 0, 1, 4, 3 };
        int[] cheeseInventory = new int[] { 5, 2, 4, 0, 6, 4 } ;
        int[] otherInventory = new int[] { 3, 1, 1, 2, 5, 4 };
        bool[] canAddBread = new bool[] { true, true, true, true, true, false };
        bool[] canAddMeat = new bool[] { true, true, false, true, true, true };
        bool[] canAddCheese = new bool[] { true, true, true, false, true, true };
        bool[] canAddOther = new bool[] { true, true, true, true, true, true };

        public bool[] getBreadBool()
        {
            return canAddBread;
        }
        public bool[] getMeatBool()
        {
            return canAddMeat;
        }
        public bool[] getCheeseBool()
        {
            return canAddCheese;
        }
        public bool[] getOtherBool()
        {
            return canAddOther;
        }
        public void setBreadToFalse(int indexToFalse)
        {
            canAddBread[indexToFalse] = false;
        }
        public void setBreadToTrue(int indexToTrue)
        {
            canAddBread[indexToTrue] = true;
        }
        public void setMeatToFalse(int indexToFalse)
        {
            canAddMeat[indexToFalse] = false;
        }
        public void setMeatToTrue(int indexToTrue)
        {
            canAddMeat[indexToTrue] = true;
        }
        public void setCheeseToFalse(int indexToFalse)
        {
            canAddCheese[indexToFalse] = false;
        }
        public void setCheeseToTrue(int indexToTrue)
        {
            canAddCheese[indexToTrue] = true;
        }
        public void setOtherToFalse(int indexToFalse)
        {
            canAddOther[indexToFalse] = false;
        }
        public void setOtherToTrue(int indexToTrue)
        {
            canAddOther[indexToTrue] = true;
        }
        public string getBreadTypeStock(int breadIndex)
        {
            string breadType = "";
                switch (breadIndex)
                {
                case 0:
                    breadType = "White Bread";
                    break;
                case 1:
                    breadType = "Wheat Bread";
                    break;
                case 2:
                    breadType = "Toasted White Bread";
                    break;
                case 3:
                    breadType = "Toasted Wheat Bread";
                    break;
                case 4:
                    breadType = "Rye Bread";
                    break;
                case 5:
                    breadType = "Multigrain Bread";
                    break;

                    default:
                    break;
                }
            return breadType;
            
            
        }
        public string getMeatTypeStock(int meatIndex)
        {
            string meatType = "";
            switch (meatIndex)
            {
                case 0:
                    meatType = "Roast Beef";
                    break;
                case 1:
                    meatType = "Ham";
                    break;
                case 2:
                    meatType = "Chicken";
                    break;
                case 3:
                    meatType = "Pepperoni";
                    break;
                case 4:
                    meatType = "Turkey";
                    break;
                case 5:
                    meatType = "Mortadella";
                    break;

                default:
                    break;

            }
            return meatType;
        }


        public string getCheeseTypeStock(int cheeseIndex)
        {
            string cheeseType = "";
            switch (cheeseIndex)
            {
                case 0:
                    cheeseType = "Cheddar";
                    break;
                case 1:
                    cheeseType = "Mozzarella";
                    break;
                case 2:
                    cheeseType = "Swiss";
                    break;
                case 3:
                    cheeseType = "Parmesan";
                    break;
                case 4:
                    cheeseType = "American";
                    break;
                case 5:
                    cheeseType = "Muenster";
                    break;

                default:
                    break;
            }
            return cheeseType;
        }

        public string getOtherTypeStock(int otherIndex)
        {
            string otherType = "";
            switch (otherIndex)
            {
                case 0:
                    otherType = "Lettuce";
                    break;
                case 1:
                    otherType = "Mushrooms";
                    break;
                case 2:
                    otherType = "Olives";
                    break;
                case 3:
                    otherType = "Guacamole";
                    break;
                case 4:
                    otherType = "Avocado";
                    break;
                case 5:
                    otherType = "Peppers";
                    break;

                default:
                    break;
            }
            return otherType;
        }

        public int[] GetBreadInventory()
        {
            return breadInventory;
        }
        public int[] GetMeatInventory()
        {
            return meatInventory;
        }
        public int[] GetCheeseInventory()
        {
            return cheeseInventory;
        }
        public int[] getOtherInventory()
        {
            return otherInventory;
        }

        public void RestockBread()
        {
            for (int i = 0; i < breadInventory.Length; i++)
            {
                breadInventory[i] += 5;
            }
        }
        public void RestockMeat()
        {
            for (int i = 0; i < meatInventory.Length; i++)
            {
                meatInventory[i] += 5;
            }
        }
        public void RestockCheese()
        {
            for (int i = 0; i < cheeseInventory.Length; i++)
            {
                cheeseInventory[i] += 5;
            }
        }
        public void RestockOther()
        {
            for (int i = 0; i < otherInventory.Length; i++)
            {
                otherInventory[i] += 5;
            }
        }
    }
}
