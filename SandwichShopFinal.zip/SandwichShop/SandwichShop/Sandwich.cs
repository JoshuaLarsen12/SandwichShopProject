﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SandwichShop
{
    class Sandwich
    {
        double subTotal = 0;
        string breadType;
        List<string> meats = new List<string>();
        List<string> cheeses = new List<string>();
        List<string> other = new List<string>();
        public Sandwich()
        {
            
        }

        public void assignBread(string bread)
        {
            breadType = bread;
        }

        public string getBreadType()
        {
            return breadType;
        }
        public double breadPrice(string bread, bool addToSubTotal)
        {
            double price = 0;
            switch (bread)
            {
                case "White Bread":
                    price = 0.75;
                    break;
                case "Wheat Bread":
                    price = 1.00;
                    break;
                case "Toasted White Bread":
                    price = 1.00;
                    break;
                case "Toasted Wheat Bread":
                    price = 1.25;
                    break;
                case "Rye Bread":
                    price = 1.50;
                    break;
                case "Multigrain Bread":
                    price = 1.75;
                    break;
                default:
                    price = 0;
                    break;
            }
            if (addToSubTotal)
            {
                subTotal += price;
            }
            
            return price;
        }

        public void addMeat(string meat)
        {
            meats.Add(meat);
        }

        public string getMeats()
        {
            double price = 0;
            string allMeats = "";
            foreach (string meat in meats)
            {
                

                switch (meat)
                {
                    case "Roast Beef":
                        price = 0.75;
                        break;
                    case "Ham":
                        price = 0.75;
                        break;
                    case "Chicken":
                        price = 0.50;
                        break;
                    case "Pepperoni":
                        price = 0.50;
                        break;
                    case "Turkey":
                        price = 0.25;
                        break;
                    case "Mortadella":
                        price = 0.25;
                        break;
                    default:
                        price = 0;
                        break;
                }
                subTotal += price;
                allMeats += string.Format("{0} - Price: {1:C}\n", meat, price);
            }
            return allMeats;
        }
            
       


        public void addCheese(string cheese)
        {
            cheeses.Add(cheese);
        }

        public string getCheeses()
        {
            string allCheeses = "";
            double price = 0;
            foreach (string cheese in cheeses)
            {
                switch (cheese)
                {
                    case "Cheddar":
                        price = 0.25;
                        break;
                    case "Mozzarella":
                        price = 0.75;
                        break;
                    case "Swiss":
                        price = 0.50;
                        break;
                    case "Parmesan":
                        price = 0.50;
                        break;
                    case "American":
                        price = 0.25;
                        break;
                    case "Muenster":
                        price = 0.75;
                        break;

                    default:
                        price = 0;
                        break;
                }
                subTotal += price;
                allCheeses += string.Format("{0} - Price: {1:C}\n", cheese, price);
            }

            return allCheeses;

        }

        public void addOther(string otherItem)
        {
            other.Add(otherItem);
        }

        public string getOthers()
        {
            double price = 0;
            string allOthers = "";

            foreach (string item in other)
            {
                switch (item)
                {
                    case "Lettuce":
                        price = 0.10;
                        break;
                    case "Mushrooms":
                        price = 0.20;
                        break;
                    case "Olives":
                        price = 0.15;
                        break;
                    case "Guacamole":
                        price = 0.30;
                        break;
                    case "Avocado":
                        price = 0.30;
                        break;
                    case "Peppers":
                        price = 0.25;
                        break;
                    default:
                        price = 0;
                        break;
                }
                subTotal += price;
                allOthers += string.Format("{0} - Price: {1:C}\n", item, price);
            }
            return allOthers;
        }
        

        public override string ToString()
        {
            return string.Format("\nBread: " + breadType + " - Price: {0:C} \nMeats:\n{1}Cheeses:\n{2}Other Ingredients:\n{3}",  breadPrice(breadType, true),  getMeats(), getCheeses(), getOthers());
        }
        public double getSandwichSubtotal()
        {
            return subTotal;
        }
    }
}
